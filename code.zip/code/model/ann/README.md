# Artificial Neural Network (ANN)

Single hidden layer neural network as a baseline for comparison.
