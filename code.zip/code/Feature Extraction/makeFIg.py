# 被用于给域名长度信息作图使用的函数
def calculateLen_figure(benign_data_calculate,malicious_data_calculate):
    returns